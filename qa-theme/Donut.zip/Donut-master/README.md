# Donut #
Clean Minimal Responsive theme for Question2Answer ( Q2A ) websites 

### What is this repository for? ###

* Question2Andwer theme 
* 1.0

### How do I get set up? ###

*Installation instructions will be added  

### Contribution guidelines ###

* Help me in testing 
* Code review
* Other guidelines
